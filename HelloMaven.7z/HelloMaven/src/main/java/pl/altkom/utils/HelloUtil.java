package pl.altkom.utils;

public class HelloUtil {

    public static String GREETING = "Hello";
    public static String hello(String name) {
        return "Hello" + " " +name;
    }
}
